# Verificação da home v0.16 — 17/11/2026

Escopo: home de módulos em Angular 22, busca compartilhada de munícipes e preservação do protótipo de conversas. Dados fictícios, executados localmente.

- **Build de produção aprovado**, sem erros ou avisos de orçamento. Angular 22.2.6 / CLI 22.2.7, Node 22.23.2. Saída: `dist/gabinete-web/browser`.
- **12 testes unitários aprovados**, em quatro arquivos: persistência do cabeçalho e da busca entre rotas; pesquisa por nome sem acentos e telefone sem máscara; estado vazio e limpeza. Incluem os oito testes já existentes dos mocks e serviços de conversas preservados.
- **5 cenários de navegador aprovados**, usando Playwright e o Chrome local: ordem dos oito acessos e aviso ao clicar; busca por nome/telefone, estado vazio e resumo; teclado; dimensões responsivas e cabeçalho fixo; acessibilidade com axe.
- **7 larguras verificadas:** 320, 390, 600, 768, 1024, 1440 e 1536 px. Botões quadrados, duas colunas até 600 px e quatro nas larguras maiores, sem rolagem horizontal. A busca permanece visível ao rolar no celular.
- **Teclado verificado:** Ctrl K na busca, setas para selecionar resultados, Enter para abrir resumo e Escape com retorno de foco.
- **Axe sem violações nas verificações padrão**, em desktop, celular, resultados da busca e resumo em modal. A verificação automatizada cobre contraste e nomes acessíveis; uma avaliação manual completa com tecnologias assistivas continua sendo uma etapa distinta.
- **Nenhuma chamada externa/API nas interações verificadas.** Fonte Inter e ícones são locais; a busca utiliza oito pessoas fictícias em memória.
- **Conversas preservadas:** os 65 arquivos da cópia v0.15 conferem com o manifesto SHA-256. Os 25 arquivos de funcionalidade e domínio de conversas também permanecem idênticos na fonte atual. O teste de navegador anterior está guardado fora da descoberta da suíte atual.
- **MCP oficial do Angular utilizado nesta tarefa:** `list_projects` identificou o workspace e `get_best_practices` devolveu o guia para Angular 22 antes das alterações. Servidor 22.2.7, cliente SDK v2.4.0 e protocolo `2026-07-28`.

Os cenários atuais estão em [tests/home.spec.ts](tests/home.spec.ts). Configuração em [playwright.config.ts](playwright.config.ts). O Chrome já instalado foi utilizado.

```sh
npm run build
npm test -- --watch=false
# Com npm start aberto em outro terminal:
npm run test:ui
npm run mcp:check
```

Os metadados MCP estão em `.angular/mcp-check.json`, com guia em `.angular/angular-best-practices.md`. O Playwright gera `playwright-report/` e `test-results/`. Esses diretórios são locais e ignorados pelo Git.

Imagens da revisão visual: [desktop](artifacts/home-modulos-desktop.png), [celular](artifacts/home-modulos-mobile.png) e [busca no celular](artifacts/home-busca-mobile.png). Resultado unitário em `artifacts/home-unit-tests.txt`.

A ordem de implementação está em [roadmap-frontend.md](../.agents/roadmap-frontend.md). Os botões mostram “Em breve”; a próxima etapa será Munícipes, conforme novo pedido. A [cópia de conversas](../docs/prototipos/README.md) contém a validação anterior, com os fluxos da antiga home.
