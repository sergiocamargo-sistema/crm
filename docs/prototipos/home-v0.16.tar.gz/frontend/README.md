# Gabinete — home em Angular 22

Prévia atualizada em **17/11/2026**, planejamento **v0.16**. A home apresenta oito módulos em botões quadrados: duas colunas no celular e quatro no desktop. A caixa de conversas anterior ficou [preservada para retomada](../docs/prototipos/README.md).

**Somente a home foi alterada nesta etapa.** Os módulos continuam para implementação posterior. Os dados da busca são fictícios; não há backend, login, conexão WhatsApp, IA ou chamadas HTTP.

## Abrir a prévia

```sh
cd /home/vini/Projects/gabinete-crm/frontend
nvm use
npm start
```

Acessar **http://127.0.0.1:4300**. O projeto já está instalado nesta máquina. Em um checkout novo, executar `npm ci` antes de `npm start`. O `.nvmrc` indica Node 22.23.2; o lockfile mantém Angular 22.2.6 e CLI 22.2.7.

No modo de desenvolvimento, o servidor verifica alterações nos arquivos a cada segundo (`poll: 1000` em `angular.json`). Ao salvar, ele recompila e atualiza a página aberta. Se o terminal deixar de responder ou recompilar, interromper com Ctrl+C e executar `npm start` novamente.

## Home e ordem das próximas etapas

1. Munícipes
2. Kanban
3. Solicitações
4. Conversas
5. Projetos de lei
6. Leis
7. Configurações
8. Relatórios

Os botões apresentam seus ícones e, nesta prévia, informam “Em breve” ao clicar. Não abrem páginas inventadas. A próxima etapa será Munícipes, conforme novo pedido do usuário. Decisões persistidas em [roadmap-frontend.md](../.agents/roadmap-frontend.md).

## Busca de munícipes no cabeçalho

O cabeçalho substitui o breadcrumb por busca de nome ou telefone. Ele fica no componente raiz, fora das rotas, para permanecer disponível nas próximas telas. No celular, o cabeçalho acompanha a rolagem.

Experimente “Mariana”, “joao” ou “11900000004”. A busca aceita nomes sem acentos e telefones sem máscara. Com dois caracteres, mostra sugestões fictícias; selecionar uma pessoa abre somente seu resumo. Não implementa a ficha de munícipes nesta etapa.

Ctrl/⌘ K foca a busca; setas, Tab, Enter e Escape permitem usar os resultados e o resumo pelo teclado. Não há busca pela API nesta entrega.

## Conversas guardadas

A fonte de conversas permanece em `src/app/features/inbox`, com seus modelos e mocks. A [cópia completa v0.15](../docs/prototipos/caixa-de-conversas-v0.15.tar.gz) preserva a antiga home, o antigo cabeçalho, estilos, imagens e testes. Os cenários de navegador originais estão também em `tests/archives/conversations-v0.15.ts`, fora da suíte atual.

Na quarta etapa, adaptar a página antiga ao novo layout compartilhado; ela ainda possui cabeçalho e atalho de busca próprios. Não restaurar a cópia sobre a home atual.

## Organização da home

```text
src/app/
  app.html                             # Cabeçalho compartilhado + router-outlet
  layout/app-header/                   # Marca, busca global e perfil fictício
  shared/components/citizen-search/     # Campo, resultados e resumo
  features/home/pages/home-page/        # Grade dos oito módulos
  core/
    data/citizens.mock.ts               # Pessoas fictícias da busca
    models/citizen-summary.ts
    repositories/citizen-search-repository.ts
    mock/mock-citizen-search.ts
    services/citizen-search.ts
  features/inbox/                      # Protótipo preservado, fora da home
```

Dados seguem componente → serviço → interface de repositório → mock. O repositório HTTP futuro será integrado às ações já descritas na API. `mockEnabled` continua `true`, inclusive em produção desta prévia.

HTML/SCSS separados, defaults standalone/OnPush/zoneless do Angular 22, signals, `@Service`, `inject()` e Signal Forms. Ícones SVG e fonte Inter são locais.

## MCP e instruções do Angular

Foram utilizados o [servidor MCP oficial do Angular CLI](https://angular.dev/ai/mcp) e as [instruções oficiais para IA](https://angular.dev/ai/develop-with-ai#custom-prompts-and-system-instructions), consultadas em 17/11/2026. O [link indicado sobre MCP](https://modelcontextprotocol.io/docs/2026-07-28/getting-started/intro) descreve o protocolo; a implementação usada como ferramenta de desenvolvimento é a que acompanha o Angular CLI.

O CLI gerou [AGENTS.md](AGENTS.md), complementado pelas preferências do projeto, incluindo templates HTML externos. Essa preferência prevalece sobre a sugestão oficial de templates inline pequenos.

Configurações prontas:

- **Codex:** [`.codex/config.toml`](../.codex/config.toml) na raiz do projeto, com Node 22 e diretório do frontend explícitos.
- **VS Code:** [`.vscode/mcp.json`](.vscode/mcp.json), abrindo a pasta `frontend`.
- **Terminal:** `npm run mcp` inicia o servidor stdio. O processo fica aguardando um cliente MCP; não é uma página web.

O servidor `angular-cli` também foi registrado pelo CLI no Codex desta máquina, restrito à pasta frontend por `--root`, preservando os demais servidores. Reabrir o projeto no cliente/editor permite carregar a nova configuração. Os caminhos de Node nas configurações correspondem a esta máquina; ajustar ao mover o projeto.

```sh
npm run mcp:check
```

A verificação usa o cliente oficial SDK v2 para o protocolo **2026-07-28**, descobre o projeto com `list_projects` e chama `get_best_practices` para o Angular instalado. Guia retornado e metadados ficam em `.angular/`, ignorados pelo Git. O cliente MCP é dependência apenas de desenvolvimento e não entra no bundle do navegador.

A comunicação com o subprocesso MCP foi validada fora do sandbox restrito desta sessão; dentro dele, o subprocesso era encerrado. Isso não exige permissão especial no terminal normal do usuário.

Este MCP ajuda a desenvolver Angular. O agente de atendimento e o futuro MCP de negócio do gabinete continuam fora desta entrega.

## Verificações

```sh
npm run build
npm test -- --watch=false
```

O build está em `dist/gabinete-web/browser`. Para verificar a interface com o servidor local já aberto:

```sh
npm run test:ui
```

O Playwright usa o Chrome já instalado em `/opt/google/chrome/chrome`, sem baixar outro navegador. Em outra máquina, informar o caminho com `CHROME_PATH=/caminho/do/chrome npm run test:ui`. `PREVIEW_URL` permite usar outra porta/origem local.

Os cenários atuais cobrem ordem dos módulos, botões quadrados em duas/quatro colunas, busca global, teclado, resumo do munícipe, cabeçalho durante rolagem, sete larguras entre 320 e 1536 px e axe em desktop/celular/resultados/modal. Os testes de repositório/serviço verificam bloqueios de responsabilidade, contato e estado do protocolo. Não são testes de API, banco ou integração real.

Prévia desktop e celular: `artifacts/`. Relatórios Playwright: `playwright-report/` e `test-results/`, todos ignorados pelo Git. Detalhes do resultado em [validacao.md](validacao.md).
