import type { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    title: 'Início · Gabinete',
    loadComponent: () =>
      import('./features/home/pages/home-page/home-page.component').then(
        (module) => module.HomePageComponent,
      ),
  },
  { path: '**', redirectTo: '' },
];
