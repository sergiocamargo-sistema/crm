import { computed, inject, Service, signal } from '@angular/core';
import { CITIZEN_SEARCH_REPOSITORY } from '../repositories/citizen-search-repository';

@Service()
export class CitizenSearchService {
  private readonly repository = inject(CITIZEN_SEARCH_REPOSITORY);
  readonly model = signal({ query: '' });
  readonly hasQuery = computed(() => this.model().query.trim().length >= 2);
  readonly results = computed(() => this.repository.search(this.model().query).slice(0, 6));

  clear(): void {
    this.model.set({ query: '' });
  }
}
