import { inject, InjectionToken } from '@angular/core';
import { environment } from '../../../environments/environment';
import { MockCitizenSearchRepository } from '../mock/mock-citizen-search';
import type { CitizenSummary } from '../models/citizen-summary';

export interface CitizenSearchRepository {
  search(query: string): readonly CitizenSummary[];
}

export const CITIZEN_SEARCH_REPOSITORY = new InjectionToken<CitizenSearchRepository>(
  'CitizenSearchRepository',
  {
    providedIn: 'root',
    factory: () => {
      if (!environment.mockEnabled)
        throw new Error('A busca desta prévia utiliza somente dados fictícios.');
      return inject(MockCitizenSearchRepository);
    },
  },
);
