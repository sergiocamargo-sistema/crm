import {
  afterNextRender,
  Injector,
  Component,
  computed,
  ElementRef,
  inject,
  signal,
  viewChild,
  viewChildren,
} from '@angular/core';
import { form, FormField } from '@angular/forms/signals';
import { CitizenSearchService } from '../../../core/services/citizen-search';
import type { CitizenSummary } from '../../../core/models/citizen-summary';
import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-citizen-search',
  imports: [IconComponent, FormField],
  templateUrl: './citizen-search.component.html',
  styleUrl: './citizen-search.component.scss',
  host: {
    '(window:keydown)': 'onGlobalKeydown($event)',
    '(document:click)': 'onDocumentClick($event)',
    '(focusout)': 'onFocusOut($event)',
  },
})
export class CitizenSearchComponent {
  protected readonly search = inject(CitizenSearchService);
  private readonly injector = inject(Injector);
  private readonly element = inject<ElementRef<HTMLElement>>(ElementRef);
  protected readonly searchForm = form(this.search.model);
  protected readonly opened = signal(false);
  protected readonly selectedCitizen = signal<CitizenSummary | null>(null);
  protected readonly resultsOpen = computed(
    () => this.opened() && this.search.hasQuery() && !this.selectedCitizen(),
  );
  private readonly searchInput = viewChild.required<ElementRef<HTMLInputElement>>('searchInput');
  private readonly resultButtons = viewChildren<ElementRef<HTMLButtonElement>>('resultButton');
  private readonly citizenDialog =
    viewChild.required<ElementRef<HTMLDialogElement>>('citizenDialog');

  protected clear(): void {
    this.search.clear();
    this.opened.set(false);
    this.searchInput().nativeElement.focus();
  }

  protected showCitizen(citizen: CitizenSummary): void {
    this.selectedCitizen.set(citizen);
    this.opened.set(false);
    this.citizenDialog().nativeElement.showModal();
  }

  protected closePreview(): void {
    this.selectedCitizen.set(null);
    this.opened.set(false);
    this.searchInput().nativeElement.focus();
  }

  protected onInputKeydown(event: KeyboardEvent): void {
    if (event.key === 'ArrowDown' && this.search.results().length > 0) {
      event.preventDefault();
      this.opened.set(true);
      afterNextRender(() => this.resultButtons()[0]?.nativeElement.focus(), {
        injector: this.injector,
      });
    } else if (event.key === 'Enter' && this.resultsOpen() && this.search.results()[0]) {
      event.preventDefault();
      this.showCitizen(this.search.results()[0]);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      this.opened.set(false);
    }
  }

  protected onResultKeydown(event: KeyboardEvent, index: number): void {
    if (event.key === 'Escape') {
      event.preventDefault();
      this.opened.set(false);
      this.searchInput().nativeElement.focus();
      this.opened.set(false);
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      this.resultButtons()[
        Math.min(index + 1, this.resultButtons().length - 1)
      ]?.nativeElement.focus();
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (index === 0) this.searchInput().nativeElement.focus();
      else this.resultButtons()[index - 1]?.nativeElement.focus();
    }
  }

  protected onGlobalKeydown(event: KeyboardEvent): void {
    if (
      (event.ctrlKey || event.metaKey) &&
      event.key.toLowerCase() === 'k' &&
      !document.querySelector('dialog[open]')
    ) {
      event.preventDefault();
      this.searchInput().nativeElement.focus();
      this.opened.set(true);
    }
  }

  protected onDocumentClick(event: MouseEvent): void {
    if (event.target instanceof Node && !this.element.nativeElement.contains(event.target))
      this.opened.set(false);
  }

  protected onFocusOut(event: FocusEvent): void {
    if (
      !(event.relatedTarget instanceof Node) ||
      !this.element.nativeElement.contains(event.relatedTarget)
    )
      this.opened.set(false);
  }

  protected onBackdropClick(event: MouseEvent): void {
    const dialog = this.citizenDialog().nativeElement;
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (
      event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom
    )
      dialog.close();
  }
}
