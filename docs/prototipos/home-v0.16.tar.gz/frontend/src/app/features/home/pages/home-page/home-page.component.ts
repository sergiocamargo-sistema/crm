import { Component, DestroyRef, inject, signal } from '@angular/core';
import { IconComponent, type IconName } from '../../../../shared/components/icon/icon.component';

interface HomeModule {
  readonly id: string;
  readonly label: string;
  readonly icon: IconName;
}

@Component({
  selector: 'app-home-page',
  imports: [IconComponent],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.scss',
})
export class HomePageComponent {
  private readonly destroyRef = inject(DestroyRef);
  protected readonly selectedModule = signal('');
  private noticeTimer: ReturnType<typeof setTimeout> | undefined;
  protected readonly modules: readonly HomeModule[] = [
    { id: 'municipes', label: 'Munícipes', icon: 'users' },
    { id: 'kanban', label: 'Kanban', icon: 'kanban' },
    { id: 'solicitacoes', label: 'Solicitações', icon: 'clipboard' },
    { id: 'conversas', label: 'Conversas', icon: 'message' },
    { id: 'projetos-de-lei', label: 'Projetos de lei', icon: 'filePen' },
    { id: 'leis', label: 'Leis', icon: 'scales' },
    { id: 'relatorios', label: 'Relatórios', icon: 'chart' },
    { id: 'configuracoes', label: 'Configurações', icon: 'settings' },
  ];

  constructor() {
    this.destroyRef.onDestroy(() => clearTimeout(this.noticeTimer));
  }
  protected selectModule(label: string): void {
    clearTimeout(this.noticeTimer);
    this.selectedModule.set(label);
    this.noticeTimer = setTimeout(() => this.selectedModule.set(''), 3500);
  }
  protected dismissNotice(): void {
    clearTimeout(this.noticeTimer);
    this.selectedModule.set('');
  }
}
