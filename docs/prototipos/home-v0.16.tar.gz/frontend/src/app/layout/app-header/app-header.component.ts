import { Component, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IconComponent } from '../../shared/components/icon/icon.component';
import { CitizenSearchComponent } from '../../shared/components/citizen-search/citizen-search.component';

@Component({
  selector: 'app-header',
  imports: [RouterLink, IconComponent, CitizenSearchComponent],
  templateUrl: './app-header.component.html',
  styleUrl: './app-header.component.scss',
})
export class AppHeaderComponent {
  // Contrato preservado para adaptar o protótipo de conversas quando esse módulo for retomado.
  readonly availability = input<'available' | 'paused'>('available');
  readonly unreadNotifications = input(2);
  readonly availabilityChanged = output<'available' | 'paused'>();
  readonly notificationsRead = output<void>();
  readonly navigationRequested = output<void>();
  readonly helpRequested = output<void>();
}
