import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const modules = [
  'Munícipes',
  'Kanban',
  'Solicitações',
  'Conversas',
  'Projetos de lei',
  'Leis',
  'Configurações',
  'Relatórios',
];

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'O que você precisa fazer hoje?' })).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
});

test('home contém oito acessos na ordem combinada e guarda conversas fora da home', async ({
  page,
}) => {
  await expect(page.locator('.module-label')).toHaveText(modules);
  await expect(page.locator('.module-tile app-icon')).toHaveCount(8);
  await expect(page.locator('app-conversation-panel')).toHaveCount(0);
  await expect(page.getByText('Espaço de trabalho', { exact: true })).toHaveCount(0);
  await page.getByRole('button', { name: 'Munícipes', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: 'Em breve' })).toContainText('Munícipes');
  await expect(page).toHaveURL(/\/$/);
  await page.getByRole('button', { name: 'Conversas', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: 'Em breve' })).toContainText('Conversas');
  await expect(page.locator('app-conversation-panel')).toHaveCount(0);
});

test('busca global por nome, telefone, estado vazio e resumo sem chamadas de API', async ({
  page,
}) => {
  const requests: string[] = [];
  page.on('request', (request) => {
    const url = new URL(request.url());
    if (!['127.0.0.1', 'localhost'].includes(url.hostname) || url.pathname.startsWith('/api/'))
      requests.push(request.url());
  });
  const search = page.getByRole('searchbox', { name: 'Buscar munícipe', exact: true });
  await search.fill('joao');
  const results = page.getByRole('region', { name: 'Resultados da busca de munícipes' });
  await expect(results).toBeVisible();
  await expect(page.locator('.citizen-result')).toHaveCount(1);
  await expect(results).toContainText('João Pereira');
  await search.fill('11900000004');
  await expect(results).toContainText('Carlos Eduardo');
  await search.fill('nao-existe-xyz');
  await expect(results).toContainText('Nenhum munícipe encontrado');
  await search.fill('mariana');
  await results.getByRole('button', { name: /Mariana Oliveira/ }).click();
  await expect(page.getByRole('dialog')).toContainText('Mariana Oliveira');
  await expect(page.getByRole('dialog')).toContainText('Jardim das Flores');
  await page.getByRole('button', { name: 'Fechar resumo do munícipe' }).click();
  await expect(search).toBeFocused();
  await page.getByRole('button', { name: 'Limpar busca' }).click();
  await expect(search).toHaveValue('');
  await expect(results).toBeHidden();
  expect(requests).toEqual([]);
});

test('atalho, setas, Enter e Escape permitem usar a busca pelo teclado', async ({ page }) => {
  const search = page.getByRole('searchbox', { name: 'Buscar munícipe', exact: true });
  await page.keyboard.press('Control+k');
  await expect(search).toBeFocused();
  await search.fill('Mariana');
  await search.press('Escape');
  await expect(page.locator('#citizen-search-results')).toBeHidden();
  await search.press('ArrowDown');
  await expect(page.locator('.citizen-result').first()).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('dialog')).toContainText('Mariana Oliveira');
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(search).toBeFocused();
});

test('botões quadrados em duas colunas no celular, quatro no desktop e busca sempre visível', async ({
  page,
}) => {
  for (const width of [320, 390, 600, 768, 1024, 1440, 1536]) {
    await page.setViewportSize({ width, height: 900 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
      width,
    );
    const geometry = await page.locator('.module-tile').evaluateAll((tiles) =>
      tiles.map((tile) => {
        const box = tile.getBoundingClientRect();
        return { x: box.x, y: box.y, width: box.width, height: box.height };
      }),
    );
    const columns = geometry.filter((tile) => Math.abs(tile.y - geometry[0].y) < 1).length;
    expect(columns).toBe(width <= 600 ? 2 : 4);
    for (const tile of geometry) expect(Math.abs(tile.width - tile.height)).toBeLessThan(1.1);
    await expect(
      page.getByRole('searchbox', { name: 'Buscar munícipe', exact: true }),
    ).toBeVisible();
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.locator('.module-tile').last().scrollIntoViewIfNeeded();
  expect(
    await page
      .getByRole('searchbox', { name: 'Buscar munícipe', exact: true })
      .evaluate((element) => element.getBoundingClientRect().top),
  ).toBeLessThan(80);
  await page.getByRole('searchbox', { name: 'Buscar munícipe', exact: true }).fill('Luciana');
  await expect(page.locator('.citizen-result')).toContainText('Luciana Alves');
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
});

test('axe em desktop, celular, resultados e resumo de munícipe', async ({ page }, testInfo) => {
  const reports = [];
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 1000 });
    const report = await new AxeBuilder({ page }).analyze();
    reports.push({ state: `home-${width}`, violations: report.violations });
    expect(
      report.violations.map((item) => ({
        id: item.id,
        nodes: item.nodes.map((node) => ({ target: node.target, summary: node.failureSummary })),
      })),
    ).toEqual([]);
  }
  await page.getByRole('searchbox', { name: 'Buscar munícipe', exact: true }).fill('Mariana');
  const results = await new AxeBuilder({ page }).analyze();
  reports.push({ state: 'resultados', violations: results.violations });
  expect(
    results.violations.map((item) => ({
      id: item.id,
      nodes: item.nodes.map((node) => ({ target: node.target, summary: node.failureSummary })),
    })),
  ).toEqual([]);
  await page.locator('.citizen-result').first().click();
  const modal = await new AxeBuilder({ page }).analyze();
  reports.push({ state: 'resumo', violations: modal.violations });
  await testInfo.attach('axe-report', {
    body: JSON.stringify(reports, null, 2),
    contentType: 'application/json',
  });
  expect(modal.violations).toEqual([]);
});
