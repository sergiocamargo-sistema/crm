# Verificação da home — 17/11/2026

Escopo: somente a home mockada do gabinete em Angular 22. As verificações foram realizadas na máquina de desenvolvimento; não demonstram backend, autorização real ou entrega de mensagens.

- **Build de produção aprovado**, sem erros ou avisos de orçamento. Angular 22.2.6 / CLI 22.2.7, com Node 22.23.2. Saída: `dist/gabinete-web/browser`.
- **9 testes unitários aprovados**, em 3 arquivos: carregamento da rota/home, busca/filtros, responsabilidade, envio bloqueado antes de assumir, nota interna, transferência, encerramento independente do protocolo, indisponibilidade e reinício dos mocks.
- **6 cenários de navegador aprovados**, usando Playwright e o Chrome local. Cobrem filtros, pesquisa, rascunhos por conversa, sugestão, resposta, anexos, notas, transferência, encerramento/reabertura, notificações, disponibilidade e reconexão simulada.
- **Teclado verificado:** foco inicial de transferência, Escape e retorno de foco de diálogos/menu, Ctrl/⌘ K na busca e Ctrl/⌘ Enter no editor.
- **7 larguras verificadas:** 320, 390, 768, 1024, 1280, 1440 e 1536 px, sem rolagem horizontal da página.
- **Axe sem violações nas verificações padrão**, incluindo contraste e nomes acessíveis, em desktop, lista móvel e contexto do munícipe em modal. Não substitui avaliação manual completa com tecnologias assistivas.
- **Nenhuma chamada externa/API durante as interações verificadas.** Fonte Inter e ícones são locais. Anexos são apenas metadados em memória.
- **MCP oficial do Angular respondendo**, com protocolo `2026-07-28`: `list_projects` identificou o workspace Angular 22 e `get_best_practices` devolveu o guia correspondente. Servidor 22.2.7 e cliente SDK v2.4.0. A validação de subprocessos exigiu execução fora do sandbox restrito da sessão.
- Servidor `angular-cli` registrado no Codex desta máquina com raiz limitada a `frontend`; configurações de projeto também disponíveis para Codex e VS Code.

Os testes funcionais e de acessibilidade estão em [tests/home.spec.ts](tests/home.spec.ts). Configuração em [playwright.config.ts](playwright.config.ts). O Chrome já instalado foi utilizado; nenhum navegador adicional foi instalado.

```sh
npm run build
npm test -- --watch=false
# Com npm start aberto em outro terminal:
npm run test:ui
npm run mcp:check
```

O teste MCP gera `.angular/mcp-check.json` e `.angular/angular-best-practices.md`. O Playwright gera `playwright-report/`, `test-results/` e imagens em `artifacts/`; esses diretórios são locais e ignorados pelo Git.

A revisão visual foi feita em desktop e celular. O estado inicial e todos os nomes, contatos, atendimentos e mensagens são fictícios. Resposta, nota, transferência, conexão e notificações continuam simuladas; nenhuma integração real foi ativada.
