# Gabinete — home em Angular 22

Primeira prévia do frontend, criada em **17/11/2026** para avaliar a home. A tela inicial é a caixa de atendimento descrita no planejamento: fila, conversa e contexto do munícipe no mesmo espaço.

**Dados fictícios, mantidos somente em memória.** Não há backend, login real, conexão com WhatsApp, IA ou chamadas aos endpoints documentados. Recarregar a página ou usar Ajuda → Reiniciar demonstração restaura os dados.

## Abrir a prévia

O projeto já está instalado nesta máquina. No terminal:

```sh
cd /home/vini/Projects/gabinete-crm/frontend
nvm use
npm start
```

Acessar **http://127.0.0.1:4300**. O `.nvmrc` seleciona Node 22.23.2, já instalado. O npm do Node 20 do sistema apresentou problema nesta máquina; usar o Node indicado pelo projeto.

Em um checkout novo, executar `npm ci` antes de `npm start`. Usar o lockfile para reproduzir as versões: Angular **22.2.6**, CLI **22.2.7**, TypeScript 6 e Vitest 4. Nenhuma instalação global adicional é necessária.

## O que experimentar

- Buscar conversas por nome, bairro, texto ou protocolo, incluindo pesquisa sem acentos.
- Filtrar Todas, Minhas, Aguardando e somente não lidas. Os contadores acompanham as alterações.
- Selecionar uma conversa, consultar o munícipe e o atendimento relacionado.
- Assumir conversa disponível, responder, usar sugestão, anexar arquivos e registrar nota interna.
- Alternar conversas sem perder rascunhos. Nota interna permanece no modo interno depois do envio.
- Transferir, encerrar e reabrir conversa, preservando mensagens e o estado independente do protocolo.
- Simular queda/reconexão pelo botão WhatsApp conectado. Offline bloqueia resposta pelo canal, mas permite notas internas.
- Mudar a disponibilidade, consultar notificações e usar os diálogos pelo teclado.
- No celular, abrir conversa, voltar à fila, consultar contexto em modal e abrir o menu lateral.

Anexos armazenam somente nome, tipo e tamanho na memória da demonstração; não há upload de bytes. Sugestões são textos prontos do mock. Notificações são da interface; não solicitam permissão nem enviam Web Push. Os nomes e números exibidos são fictícios.

Os módulos restantes aparecem no menu como próximas etapas. O botão Novo atendimento explica o limite desta primeira prévia; não abre um cadastro funcional ou outra página.

## Organização

```text
src/app/
  core/
    data/inbox.mock.ts             # Pessoas, conversas e equipe fictícias
    models/inbox.ts                # Modelos tipados da visualização
    repositories/inbox-repository.ts
    mock/mock-inbox.ts             # Operações e estado em memória
  features/inbox/
    services/inbox.ts              # Busca, seleção, filtros e ações da home
    components/                   # Fila, conversa, editor, contexto e resumo
    pages/inbox-page/              # Composição da única página
  layout/                         # Cabeçalho e navegação
  shared/components/icon/          # Ícones SVG locais
```

Fluxo: **componente → serviço → interface de repositório → mock**. Sem CRUD genérico, implementação HTTP vazia ou endpoints inventados. Futuro repositório HTTP deverá adaptar as ações ao [contrato por telas](../docs/api/README.md).

`environment.mockEnabled` permanece `true` também no build de produção desta prévia. Desativá-lo sem implementar outra fonte gera erro explícito; não inicia acesso a uma API suposta.

Componentes usam HTML/SCSS separados, defaults standalone/OnPush/zoneless do Angular 22, signals, `inject()`, `@Service`, `input()`/`output()` e Signal Forms. A home é carregada por rota lazy. A fonte Inter e os ícones são locais; o navegador não precisa buscar fontes em serviços externos.

## MCP e instruções do Angular

Foram utilizados o [servidor MCP oficial do Angular CLI](https://angular.dev/ai/mcp) e as [instruções oficiais para IA](https://angular.dev/ai/develop-with-ai#custom-prompts-and-system-instructions), consultadas em 17/11/2026. O [link indicado sobre MCP](https://modelcontextprotocol.io/docs/2026-07-28/getting-started/intro) descreve o protocolo; a implementação usada como ferramenta de desenvolvimento é a que acompanha o Angular CLI.

O CLI gerou [AGENTS.md](AGENTS.md), complementado pelas preferências do projeto, incluindo templates HTML externos. Essa preferência prevalece sobre a sugestão oficial de templates inline pequenos.

Configurações prontas:

- **Codex:** [`.codex/config.toml`](../.codex/config.toml) na raiz do projeto, com Node 22 e diretório do frontend explícitos.
- **VS Code:** [`.vscode/mcp.json`](.vscode/mcp.json), abrindo a pasta `frontend`.
- **Terminal:** `npm run mcp` inicia o servidor stdio. O processo fica aguardando um cliente MCP; não é uma página web.

O servidor `angular-cli` também foi registrado pelo CLI no Codex desta máquina, restrito à pasta frontend por `--root`, preservando os demais servidores. Reabrir o projeto no cliente/editor permite carregar a nova configuração. Os caminhos de Node nas configurações correspondem a esta máquina; ajustar ao mover o projeto.

```sh
npm run mcp:check
```

A verificação usa o cliente oficial SDK v2 para o protocolo **2026-07-28**, descobre o projeto com `list_projects` e chama `get_best_practices` para o Angular instalado. Guia retornado e metadados ficam em `.angular/`, ignorados pelo Git. O cliente MCP é dependência apenas de desenvolvimento e não entra no bundle do navegador.

A comunicação com o subprocesso MCP foi validada fora do sandbox restrito desta sessão; dentro dele, o subprocesso era encerrado. Isso não exige permissão especial no terminal normal do usuário.

Este MCP ajuda a desenvolver Angular. O agente de atendimento e o futuro MCP de negócio do gabinete continuam fora desta entrega.

## Verificações

```sh
npm run build
npm test -- --watch=false
```

O build está em `dist/gabinete-web/browser`. Para verificar a interface com o servidor local já aberto:

```sh
npm run test:ui
```

O Playwright usa o Chrome já instalado em `/opt/google/chrome/chrome`, sem baixar outro navegador. Em outra máquina, informar o caminho com `CHROME_PATH=/caminho/do/chrome npm run test:ui`. `PREVIEW_URL` permite usar outra porta/origem local.

Os testes cobrem busca/filtros, rascunhos, sugestões, respostas, anexos simulados, notas, transferência, encerramento, disponibilidade, desconexão, teclado, sete larguras entre 320 e 1536 px e axe em desktop/celular/modal. Os testes de repositório/serviço verificam bloqueios de responsabilidade, contato e estado do protocolo. Não são testes de API, banco ou integração real.

Prévia desktop e celular: `artifacts/`. Relatórios Playwright: `playwright-report/` e `test-results/`, todos ignorados pelo Git. Detalhes do resultado em [validacao.md](validacao.md).
