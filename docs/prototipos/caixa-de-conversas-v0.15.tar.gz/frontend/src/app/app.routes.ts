import type { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    title: 'Caixa de atendimento · Gabinete',
    loadComponent: () =>
      import('./features/inbox/pages/inbox-page/inbox-page.component').then(
        (module) => module.InboxPageComponent,
      ),
  },
  { path: '**', redirectTo: '' },
];
