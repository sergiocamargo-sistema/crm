import { Component, input, output } from '@angular/core';
import { IconComponent } from '../../shared/components/icon/icon.component';

@Component({
  selector: 'app-header',
  imports: [IconComponent],
  templateUrl: './app-header.component.html',
  styleUrl: './app-header.component.scss',
})
export class AppHeaderComponent {
  readonly availability = input<'available' | 'paused'>('available');
  readonly unreadNotifications = input(2);
  readonly availabilityChanged = output<'available' | 'paused'>();
  readonly notificationsRead = output<void>();
  readonly navigationRequested = output<void>();
  readonly helpRequested = output<void>();
  protected setAvailability(value: 'available' | 'paused'): void {
    this.availabilityChanged.emit(value);
    document.getElementById('availability-popover')?.hidePopover();
  }
}
