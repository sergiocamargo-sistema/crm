import { computed, inject, Service, signal } from '@angular/core';
import { INBOX_REPOSITORY } from '../../../core/repositories/inbox-repository';
import { CURRENT_USER, TEAM } from '../../../core/data/inbox.mock';
import type { ComposeMessage, InboxCounts, QueueFilter } from '../../../core/models/inbox';

const normalize = (text: string): string =>
  text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();

@Service()
export class InboxService {
  private readonly repository = inject(INBOX_REPOSITORY);
  readonly user = CURRENT_USER;
  readonly team = TEAM.filter((member) => member.id !== CURRENT_USER.id);
  readonly conversations = this.repository.conversations;
  readonly selectedId = signal('mariana');
  readonly query = signal('');
  readonly filter = signal<QueueFilter>('all');
  readonly onlyUnread = signal(false);
  readonly connected = signal(true);
  readonly availability = signal<'available' | 'paused'>('available');
  readonly selected = computed(
    () =>
      this.conversations().find((conversation) => conversation.id === this.selectedId()) ?? null,
  );
  readonly counts = computed<InboxCounts>(() => ({
    all: this.conversations().length,
    mine: this.conversations().filter(
      (conversation) => conversation.owner?.id === this.user.id && conversation.status === 'active',
    ).length,
    waiting: this.conversations().filter((conversation) => conversation.status === 'waiting')
      .length,
    active: this.conversations().filter((conversation) => conversation.status === 'active').length,
    closed: this.conversations().filter((conversation) => conversation.status === 'closed').length,
    unread: this.conversations().filter((conversation) => conversation.unread > 0).length,
  }));
  readonly filtered = computed(() => {
    const terms = normalize(this.query().trim()).split(/\s+/).filter(Boolean);
    return this.conversations().filter((conversation) => {
      const matchesFilter =
        this.filter() === 'all' ||
        (this.filter() === 'mine' &&
          conversation.owner?.id === this.user.id &&
          conversation.status === 'active') ||
        (this.filter() === 'waiting' && conversation.status === 'waiting');
      const haystack = normalize(
        `${conversation.citizen.name} ${conversation.citizen.neighborhood} ${conversation.preview} ${conversation.request?.protocol ?? ''} ${conversation.request?.title ?? ''}`,
      );
      return (
        matchesFilter &&
        (!this.onlyUnread() || conversation.unread > 0) &&
        terms.every((term) => haystack.includes(term))
      );
    });
  });

  select(id: string): void {
    this.selectedId.set(id);
    this.repository.markRead(id);
  }

  assume(): void {
    const id = this.selectedId();
    if (this.availability() === 'paused')
      throw new Error('Altere sua disponibilidade para assumir uma conversa.');
    this.repository.assume(id);
  }

  send(command: ComposeMessage): boolean {
    if (command.mode === 'reply' && !this.connected())
      throw new Error('Reconecte o canal antes de responder pelo WhatsApp.');
    return this.repository.send(this.selectedId(), command);
  }

  transfer(staffId: string): void {
    this.repository.transfer(this.selectedId(), staffId);
  }
  close(): void {
    this.repository.close(this.selectedId());
  }

  reset(): void {
    this.repository.reset();
    this.selectedId.set('mariana');
    this.query.set('');
    this.filter.set('all');
    this.onlyUnread.set(false);
    this.connected.set(true);
    this.availability.set('available');
  }
}
