import { inject, InjectionToken } from '@angular/core';
import type { ComposeMessage, InboxDataSource } from '../models/inbox';
import { MockInboxRepository } from '../mock/mock-inbox';
import { environment } from '../../../environments/environment';

export interface InboxRepository extends InboxDataSource {
  markRead(conversationId: string): void;
  assume(conversationId: string): void;
  send(conversationId: string, message: ComposeMessage): boolean;
  transfer(conversationId: string, staffId: string): void;
  close(conversationId: string): void;
  reset(): void;
}

export const INBOX_REPOSITORY = new InjectionToken<InboxRepository>('InboxRepository', {
  providedIn: 'root',
  factory: () => {
    if (!environment.mockEnabled) {
      throw new Error(
        'Esta prévia dispõe somente do repositório mock. A API ainda não está implementada.',
      );
    }
    return inject(MockInboxRepository);
  },
});
