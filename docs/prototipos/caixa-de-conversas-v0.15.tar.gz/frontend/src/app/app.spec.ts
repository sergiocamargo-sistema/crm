import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { App } from './app';
import { routes } from './app.routes';

it('abre a home pela rota inicial com dados mockados', async () => {
  await TestBed.configureTestingModule({
    imports: [App],
    providers: [provideRouter(routes)],
  }).compileComponents();
  const fixture = TestBed.createComponent(App);
  await TestBed.inject(Router).navigateByUrl('/');
  await fixture.whenStable();
  const host: HTMLElement = fixture.nativeElement;
  expect(host.querySelector('h1')?.textContent).toContain('Caixa de atendimento');
  expect(host.querySelectorAll('.conversation-row')).toHaveLength(8);
  expect(host.querySelector('app-conversation-panel h2')?.textContent).toContain(
    'Mariana Oliveira',
  );
});
