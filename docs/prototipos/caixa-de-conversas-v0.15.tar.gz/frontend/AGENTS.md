
You are an expert in TypeScript, Angular, and scalable web application development. You write functional, maintainable, performant, and accessible code following Angular and TypeScript best practices.

## TypeScript Best Practices

- Use strict type checking
- Prefer type inference when the type is obvious
- Avoid the `any` type; use `unknown` when type is uncertain

## Angular Best Practices

- Always use standalone components over NgModules
- Must NOT set `standalone: true` inside Angular decorators. It's the default in Angular v20+.
- Do NOT set `changeDetection: ChangeDetectionStrategy.OnPush` explicitly. `OnPush` is the default in Angular v22+.
- Use signals for state management
- Implement lazy loading for feature routes
- Do NOT use the `@HostBinding` and `@HostListener` decorators. Put host bindings inside the `host` object of the `@Component` or `@Directive` decorator instead
- Use `NgOptimizedImage` for all static images.
  - `NgOptimizedImage` does not work for inline base64 images.

## Accessibility Requirements

- It MUST pass all AXE checks.
- It MUST follow all WCAG AA minimums, including focus management, color contrast, and ARIA attributes.

### Components

- Keep components small and focused on a single responsibility
- Use `input()` and `output()` functions instead of decorators
- Use `computed()` for derived state
- Prefer inline templates for small components
- Prefer Signal Forms (`@angular/forms/signals`) for new forms. They are stable in Angular v22+ and provide signal-based state, type-safe field access, and schema-based validation
- When not using Signal Forms, prefer Reactive forms instead of Template-driven ones
- Do NOT use `ngClass`, use `class` bindings instead
- Do NOT use `ngStyle`, use `style` bindings instead
- When using external templates/styles, use paths relative to the component TS file.

## State Management

- Use signals for local component state
- Use `computed()` for derived state
- Keep state transformations pure and predictable
- Do NOT use `mutate` on signals, use `update` or `set` instead

## Templates

- Keep templates simple and avoid complex logic
- Use native control flow (`@if`, `@for`, `@switch`) instead of `*ngIf`, `*ngFor`, `*ngSwitch`
- Use the async pipe to handle observables
- Do not assume globals like (`new Date()`) are available.

## Services

- Design services around a single responsibility
- Use the `providedIn: 'root'` option for singleton services
- Prefer the `@Service` decorator over `@Injectable({providedIn: 'root'})` for new singleton services (Angular v22+)
- Use the `inject()` function instead of constructor injection

## Instruções específicas deste projeto

- Fonte: https://angular.dev/ai/develop-with-ai#custom-prompts-and-system-instructions (consultada em 17/11/2026).
- Templates sempre em arquivos `.html` separados usando `templateUrl`, inclusive em componentes pequenos. Esta preferência do usuário prevalece sobre a sugestão de templates inline acima.
- Nesta etapa, implementar somente a home/caixa de atendimento com dados fictícios em memória. Não criar páginas dos demais módulos, backend, login real, chamadas HTTP ou integrações WhatsApp/IA.
- Componentes → serviço da funcionalidade → interface de repositório → implementação mock. Modelar ações da tela, sem CRUD genérico ou implementação HTTP antecipada.
- `mockEnabled` permanece true tanto em desenvolvimento quanto no build de produção deste protótipo.
- Usar os defaults do Angular 22: standalone, OnPush e zoneless; signals, inputs/outputs funcionais, inject, @Service e Signal Forms para os controles de formulário.
- Navegação e diálogos devem funcionar por teclado, com foco visível, labels e contraste AA. Validar desktop e celular.
- O MCP solicitado é o servidor oficial do Angular CLI (`ng mcp`), como ferramenta de desenvolvimento. O protocolo MCP não deve virar dependência/servidor da aplicação do gabinete.

## Uso obrigatório do MCP em cada tarefa de frontend

Aplicar a norma permanente de `/home/vini/.agents/INSTRUCTIONS.md`. Antes de alterar código nesta aplicação:

1. Executar `list_projects` no MCP oficial do Angular e selecionar o workspace deste frontend.
2. Executar `get_best_practices` com o `workspacePath` do `angular.json` retornado e aplicar as instruções oficiais compatíveis com a versão instalada.
3. Usar as ferramentas pertinentes do MCP durante a tarefa. Se não estiverem expostas na sessão, usar um cliente MCP/stdio compatível; `npm run mcp:check` já verifica a conexão e consulta essas duas ferramentas neste projeto.

A norma também vale para correções pequenas, estilos, revisão e testes. A configuração do servidor e o guia salvo de uma tarefa anterior não substituem o uso efetivo do MCP no início de uma nova tarefa.
